import { useState } from 'react';
import { Target, Upload, Award, Zap, ArrowRight, CheckCircle } from 'lucide-react';
import axios from 'axios';

function App() {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    branch: 'CSE',
    graduationYear: '2026',
    javaLevel: 3,
    pythonLevel: 3,
    dsaLevel: 3,
    systemDesignLevel: 2,
    dbmsLevel: 3,
    projectsCount: 3,
    portfolioUrl: '',
    communicationSelf: 3,
    mockInterviews: 2,
    resume: null
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleNumberChange = (name, value) => {
    setFormData(prev => ({ ...prev, [name]: parseInt(value) }));
  };

  const handleFileChange = (e) => {
    if (e.target.files[0]) {
      setFormData(prev => ({ ...prev, resume: e.target.files[0] }));
    }
  };

  const handleSubmit = async () => {
    if (!formData.resume) {
      alert("Please upload your resume (PDF)");
      return;
    }

    setLoading(true);
    const data = new FormData();

    Object.keys(formData).forEach(key => {
      if (formData[key] !== null && formData[key] !== undefined) {
        data.append(key, formData[key]);
      }
    });

    try {
      const response = await axios.post('http://localhost:8080/api/assess/submit', data, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      setResult(response.data);
      setStep(4);
    } catch (error) {
      console.error(error);
      alert("Something went wrong. Please try again.");
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-950 text-white">
      <div className="max-w-4xl mx-auto px-6 py-12">

        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <div className="bg-indigo-600 p-4 rounded-3xl">
              <Target className="w-14 h-14" />
            </div>
          </div>
          <h1 className="text-6xl font-bold mb-3 bg-gradient-to-r from-white via-indigo-300 to-indigo-400 bg-clip-text text-transparent">
            InterviewReady
          </h1>
          <p className="text-xl text-slate-400">Assess your interview readiness in under 2 minutes</p>
        </div>

        {/* Progress */}
        <div className="flex gap-3 mb-10">
          {[1, 2, 3, 4].map((s) => (
            <div
              key={s}
              className={`h-2.5 flex-1 rounded-full transition-all ${step >= s ? 'bg-indigo-500' : 'bg-slate-700'}`}
            />
          ))}
        </div>

        {/* Step 1: Basic Info */}
        {step === 1 && (
          <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-700 rounded-3xl p-10">
            <h2 className="text-3xl font-semibold mb-8">Tell us about yourself</h2>
            <div className="grid grid-cols-2 gap-6">
              <input type="text" name="fullName" placeholder="Full Name" value={formData.fullName} onChange={handleInputChange} className="bg-slate-800 border border-slate-600 rounded-2xl px-5 py-4 focus:outline-none focus:border-indigo-500" />
              <input type="email" name="email" placeholder="Email" value={formData.email} onChange={handleInputChange} className="bg-slate-800 border border-slate-600 rounded-2xl px-5 py-4 focus:outline-none focus:border-indigo-500" />
              <select name="branch" value={formData.branch} onChange={handleInputChange} className="bg-slate-800 border border-slate-600 rounded-2xl px-5 py-4">
                <option value="CSE">Computer Science</option>
                <option value="IT">Information Technology</option>
                <option value="ECE">Electronics</option>
                <option value="MECH">Mechanical</option>
              </select>
              <select name="graduationYear" value={formData.graduationYear} onChange={handleInputChange} className="bg-slate-800 border border-slate-600 rounded-2xl px-5 py-4">
                <option value="2025">2025</option>
                <option value="2026">2026</option>
                <option value="2027">2027</option>
              </select>
            </div>
            <button onClick={() => setStep(2)} className="mt-8 w-full bg-indigo-600 hover:bg-indigo-700 py-5 rounded-2xl text-lg font-semibold flex items-center justify-center gap-3">
              Next <ArrowRight className="w-6 h-6" />
            </button>
          </div>
        )}

        {/* Step 2: Technical Skills */}
        {step === 2 && (
          <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-700 rounded-3xl p-10">
            <h2 className="text-3xl font-semibold mb-8">Rate your Technical Skills (1-5)</h2>
            <div className="space-y-8">
              {[
                { label: "Java / OOP", name: "javaLevel" },
                { label: "Python", name: "pythonLevel" },
                { label: "DSA", name: "dsaLevel" },
                { label: "System Design", name: "systemDesignLevel" },
                { label: "DBMS / SQL", name: "dbmsLevel" },
                { label: "Communication", name: "communicationSelf" }
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between">
                  <label className="text-lg">{item.label}</label>
                  <input
                    type="range" min="1" max="5" value={formData[item.name]}
                    onChange={(e) => handleNumberChange(item.name, e.target.value)}
                    className="w-1/2 accent-indigo-500"
                  />
                  <span className="font-bold text-xl w-12 text-right">{formData[item.name]}/5</span>
                </div>
              ))}
            </div>
            <button onClick={() => setStep(3)} className="mt-10 w-full bg-indigo-600 hover:bg-indigo-700 py-5 rounded-2xl text-lg font-semibold">
              Continue to Projects
            </button>
          </div>
        )}

        {/* Step 3: Projects & Resume */}
        {step === 3 && (
          <div className="bg-slate-900/80 backdrop-blur-xl border border-slate-700 rounded-3xl p-10">
            <h2 className="text-3xl font-semibold mb-8">Projects & Resume</h2>

            <div className="space-y-8">
              <div>
                <label className="block text-lg mb-3">Number of Good Projects</label>
                <input type="number" name="projectsCount" value={formData.projectsCount} onChange={handleInputChange} className="bg-slate-800 border border-slate-600 rounded-2xl px-5 py-4 w-full" min="0" />
              </div>

              <div>
                <label className="block text-lg mb-3">Portfolio / GitHub Link</label>
                <input type="url" name="portfolioUrl" placeholder="https://github.com/yourusername" value={formData.portfolioUrl} onChange={handleInputChange} className="bg-slate-800 border border-slate-600 rounded-2xl px-5 py-4 w-full" />
              </div>

              <div>
                <label className="block text-lg mb-3">Upload Resume (PDF) <span className="text-red-400">*</span></label>
                <input type="file" accept=".pdf" onChange={handleFileChange} className="block w-full text-sm text-slate-400 file:mr-4 file:py-3 file:px-6 file:rounded-2xl file:border-0 file:bg-indigo-600 file:text-white" />
              </div>
            </div>

            <button
              onClick={handleSubmit}
              disabled={loading}
              className="mt-10 w-full bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-600 py-6 rounded-3xl text-xl font-semibold flex items-center justify-center gap-3"
            >
              {loading ? "Analyzing Your Profile..." : "Get My Readiness Score"}
              {!loading && <Award className="w-6 h-6" />}
            </button>
          </div>
        )}

        {/* Step 4: Result */}
        {step === 4 && result && (
          <div className="bg-slate-900/90 backdrop-blur-2xl border border-slate-700 rounded-3xl p-12">
            <div className="text-center mb-12">
              <div className="text-8xl font-bold text-emerald-400 mb-2">{result.overallScore}</div>
              <p className="text-4xl font-semibold">{result.readinessLevel}</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
              {Object.entries(result.categoryScores).map(([key, value]) => (
                <div key={key} className="bg-slate-800/80 rounded-2xl p-6 text-center border border-slate-700">
                  <p className="text-slate-400 capitalize mb-2">{key}</p>
                  <p className="text-6xl font-bold text-white">{value}</p>
                </div>
              ))}
            </div>

            {/* Action Plan */}
            <div className="bg-slate-800/80 rounded-3xl p-10">
              <h3 className="text-2xl font-semibold mb-8 flex items-center gap-3">
                <Zap className="text-yellow-400" /> Your Personalized 7-Day Action Plan
              </h3>
              <div className="space-y-6">
                {result.actionPlan.map((item, index) => (
                  <div key={index} className="flex gap-5 bg-slate-900 p-6 rounded-2xl">
                    <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center flex-shrink-0 font-bold">{index + 1}</div>
                    <div>
                      <div className="font-semibold text-lg">{item.title}</div>
                      <div className="text-slate-400 mt-1">{item.description}</div>
                      <span className={`inline-block mt-3 text-xs px-4 py-1 rounded-full ${item.priority === 'High' ? 'bg-red-500/20 text-red-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                        {item.priority} Priority
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={() => window.location.reload()}
              className="mt-10 w-full py-5 bg-slate-700 hover:bg-slate-600 rounded-2xl text-lg font-medium"
            >
              Take Assessment Again
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;