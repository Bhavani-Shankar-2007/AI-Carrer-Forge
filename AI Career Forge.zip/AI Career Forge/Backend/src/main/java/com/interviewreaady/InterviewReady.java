package com.interviewready;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.Service;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import lombok.Data;
import lombok.AllArgsConstructor;
import java.util.*;

// ==================== MAIN APPLICATION ====================

@SpringBootApplication
public class InterviewReady {
    public static void main(String[] args) {
        SpringApplication.run(InterviewReady.class, args);
    }
}

// ==================== DTOs ====================

@Data
class AssessmentRequest {
    private String fullName;
    private String email;
    private String branch;
    private String graduationYear;

    private MultipartFile resume;

    private Integer javaLevel;
    private Integer pythonLevel;
    private Integer dsaLevel;
    private Integer systemDesignLevel;
    private Integer dbmsLevel;

    private Integer projectsCount;
    private String portfolioUrl;
    private Integer communicationSelf;
    private Integer mockInterviews;
}

@Data
@AllArgsConstructor
class AssessmentResponse {
    private int overallScore;
    private String readinessLevel;
    private CategoryScores categoryScores;
    private List<String> strengths;
    private List<String> improvements;
    private List<ActionItem> actionPlan;
}

@Data
@AllArgsConstructor
class CategoryScores {
    private int technical;
    private int resume;
    private int communication;
    private int portfolio;
}

@Data
@AllArgsConstructor
class ActionItem {
    private String title;
    private String description;
    private String priority;
}

// ==================== SERVICE ====================

@Service
class AssessmentService {

    public AssessmentResponse evaluate(AssessmentRequest req) throws Exception {
        int technicalScore = calculateTechnicalScore(req);
        int resumeScore = analyzeResume(req.getResume());
        int commScore = (req.getCommunicationSelf() != null ? req.getCommunicationSelf() : 3) * 20;
        int portfolioScore = calculatePortfolioScore(req);

        int overallScore = (int) Math.round(
                technicalScore * 0.40 +
                resumeScore * 0.25 +
                commScore * 0.20 +
                portfolioScore * 0.15
        );

        String level = getReadinessLevel(overallScore);

        List<String> strengths = new ArrayList<>();
        List<String> improvements = new ArrayList<>();
        List<ActionItem> plan = generateActionPlan();

        populateFeedback(strengths, improvements, technicalScore, resumeScore, commScore, portfolioScore);

        return new AssessmentResponse(overallScore, level,
                new CategoryScores(technicalScore, resumeScore, commScore, portfolioScore),
                strengths, improvements, plan);
    }

    private int calculateTechnicalScore(AssessmentRequest req) {
        int sum = (req.getJavaLevel() != null ? req.getJavaLevel() : 3) +
                  (req.getPythonLevel() != null ? req.getPythonLevel() : 3) +
                  (req.getDsaLevel() != null ? req.getDsaLevel() : 3) +
                  (req.getSystemDesignLevel() != null ? req.getSystemDesignLevel() : 2) +
                  (req.getDbmsLevel() != null ? req.getDbmsLevel() : 3);
        return Math.min(100, sum * 4);
    }

    private int calculatePortfolioScore(AssessmentRequest req) {
        int score = (req.getProjectsCount() != null ? req.getProjectsCount() : 0) * 18;
        if (req.getPortfolioUrl() != null && !req.getPortfolioUrl().trim().isEmpty()) score += 35;
        return Math.min(100, score);
    }

    private int analyzeResume(MultipartFile file) {
        if (file == null || file.isEmpty()) return 58;
        try {
            PDDocument doc = PDDocument.load(file.getInputStream());
            String text = new PDFTextStripper().getText(doc).toLowerCase();
            doc.close();

            int score = 50;
            if (text.contains("project") || text.contains("internship")) score += 20;
            if (text.contains("github") || text.contains("leetcode")) score += 15;
            if (text.contains("led") || text.contains("developed")) score += 15;
            return Math.min(95, score);
        } catch (Exception e) {
            return 60;
        }
    }

    private String getReadinessLevel(int score) {
        if (score >= 85) return "Excellent - Job Ready";
        if (score >= 70) return "Good - Ready with Minor Prep";
        if (score >= 50) return "Average - Needs Improvement";
        return "Beginner - Significant Preparation Needed";
    }

    private void populateFeedback(List<String> strengths, List<String> improvements,
                                  int tech, int resume, int comm, int port) {
        if (tech >= 65) strengths.add("Strong Technical Foundation");
        if (resume >= 70) strengths.add("Professional Resume");
        if (comm >= 65) strengths.add("Good Communication Confidence");

        if (tech < 60) improvements.add("Improve DSA & Core Programming");
        if (resume < 65) improvements.add("Enhance Resume with Achievements");
        if (comm < 60) improvements.add("Practice Communication Skills");
    }

    private List<ActionItem> generateActionPlan() {
        List<ActionItem> plan = new ArrayList<>();
        plan.add(new ActionItem("Daily DSA", "Solve 5-8 LeetCode problems daily", "High"));
        plan.add(new ActionItem("Resume Revision", "Quantify achievements with numbers", "High"));
        plan.add(new ActionItem("Mock Interviews", "Give 3 mock interviews this week", "Medium"));
        plan.add(new ActionItem("Portfolio", "Upload projects on GitHub", "Medium"));
        return plan;
    }
}

// ==================== CONTROLLER ====================

@RestController
@CrossOrigin(origins = "*")
class AssessmentController {

    private final AssessmentService service;

    public AssessmentController(AssessmentService service) {
        this.service = service;
    }

    @PostMapping("/api/assess/submit")
    public ResponseEntity<AssessmentResponse> submitAssessment(@ModelAttribute AssessmentRequest request) throws Exception {
        AssessmentResponse response = service.evaluate(request);
        return ResponseEntity.ok(response);
    }
}